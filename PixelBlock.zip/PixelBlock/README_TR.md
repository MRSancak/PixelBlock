# PixelBlock — Geliştirme Durumu

ÖNEMLİ: Bu sürüm geliştirme ortamında derlenemedi/test edilemedi (Godot ve dotnet yoktu, ağ erişimi kapalıydı).
Godot 4.7 (.NET) ile açın; ilk derlemede çıkan hataları düzeltmek gerekebilir.

## Kontroller
WASD hareket · Space zıpla · Shift koş · Fare bakış · E / Tab envanter+üretim · F4 kamera (FPS/TPS)
PageUp/PageDown TPS yakınlık · Q eşya at · Sol tık kır/saldır · Sağ tık yerleştir/kullan/besle · G uçma

## Son düzeltmeler
- Oyun adı PixelBlock oldu (proje, assembly, namespace, ana menü başlığı)
- Dünya artık "İnşa" modunda açılıyor: blok kırma/koyma, hotbar ve eldeki eşya ekranda görünür
- Hayvanlara ve düşmanlara eldeki aletle hasar verilir (sol tık)
- Fare varsayılan olarak yakalanır (Ayarlar'dan değiştirilebilir)
- Tüm .cs dosyalarındaki // yorumları temizlendi
- Olmayan godot_ai eklentisine ait autoload/eklenti satırları project.godot'tan kaldırıldı

## Yapıldı
- Türkçe ana menü (arka plan görüntüsü, animasyonlar), yeni dünya + Seed, Türkçe ayarlar
- Grafik: kalite ön ayarları, gölge, SSAO, bloom, hacimsel sis, kenar yumuşatma, görüş mesafesi, FPS, VSync, çözünürlük, tam ekran
- Envanter (36 yuva, sürükle-bırak, yere atma), üretim + Üretim Masası, aletler, blok düşürme
- Tarım: çapa, tohum/fidan, sulama (kova/yağmur/su yakını), gübre, 18 ürün, mevsime bağlı büyüme, hasat, yeniden meyve verme
- Mevsimler (4 gün/mevsim, çimen/yaprak renk değişimi), hava: güneşli/bulutlu/yağmur/fırtına/kar/sis
- Biyomlar: orman, yoğun orman, çayır, ova, dağ, kar, çöl, bataklık + nehirler
- Hayvanlar (10 tür, kutu modeller): dolaşma, otlama, su içme, dinlenme, uyuma, kaçma, kovalama, takip, avcı-av, besleme, çiftleştirme, yavru, süt/yün/yumurta/et
- TPS kamera (duvar çarpışmalı), karakter oluşturma (yüz, saç, ten, göz, kıyafet, aksesuar) ve animasyonlar
- LAN çok oyunculu: Host/Katıl, LAN listesi, oyuncu konum/hareket/animasyon, blok, hayvan, ekin, zaman/hava senkronu; envanter host'ta oyuncu adına saklanır
- Piksel görünüm: karakter, hayvan, bitki ve yerdeki eşyalar piksel dokulu kutu/dikdörtgenlerden oluşur
- Kayıt: seed, bloklar, envanter yuvaları, ekinler, hayvanlar, gün/mevsim, karakter

## Bilinen eksikler
- Gerçek asset yok: tüm modeller/ikonlar kodla çizilmiş yer tutucu şekiller
- Çok oyunculuda istemci yalnızca hayvana vurabilir/ekin ekip hasat edebilir; hayvan besleme, süt ve yün alma istemcide yok. Özel (dedicated) sunucu yok
- Göl yok (yalnızca nehir/deniz); hayvan sesleri basit sentez

## Son eklenenler

- **Envanter (Tab):** 27 gözlü ana envanter + altta oyundaki hızlı erişim çubuğunun aynısı (seçili kutu vurgulanır). Hızlı erişim dolunca yeni eşyalar envantere düşer.
- **Açlık çubuğu:** Zamanla ve koşarken azalır; sıfırda can yavaşça düşer; tokken can yenilenir. Yiyecekler sağ tıkla yenir (havaya bakarken de).
- **Et:** Hayvanlar çiğ et bırakır (yenebilir, +3). **Kamp Ateşi** (2 kütük + 3 parke taşı) ile pişirilir: ateşe bakıp sağ tık ya da envanterden "Pişmiş Et" tarifi (+9).
- **Yün** artık yere konabilen bir bloktur.
- **Sohbet:** `Enter` ya da `/` ile açılır. `/yardim` komut listesini gösterir (`/oyunmodu`, `/yaratici`, `/hayatta`, `/zaman`, `/hava`, `/ver`, `/esyalar`, `/tp`, `/konum`, `/can`, `/doyur`, `/temizle`). `Tab` komut tamamlar, Yukarı/Aşağı geçmişi gezer. (Şimdilik sohbet yerel; çok oyunculuda diğer oyunculara gitmez.)
- **Yaratıcı mod:** `G` veya `/yaratici`. Tab ile açılan envanterde "Yaratıcı" sekmesinde tüm bloklar/eşyalar var; tıkla ya da hızlı erişim kutusuna sürükle. Yaratıcıda blok koymak/kırmak envanteri tüketmez, açlık yoktur.

## Madenler, zırh, yabani bitkiler, yeni karakter

- **Madenler:** Yeraltında kömür, bakır, demir ve altın damarları var. Kömür için ahşap, bakır/demir için taş, altın için demir kazma gerekir; yetersiz aletle kırınca eşya düşmez. Cevher ham maden verir (Ham Bakır/Demir/Altın, Kömür).
- **Eritme:** Kamp Ateşi yakınında "Külçe" tarifleri (1 ham maden + 1 kömür). Külçelerden **bakır ve demir** kazma/balta/kürek/çapa/kılıç ve **zırh setleri** (miğfer, zırh, pantolon, bot) üretilir (masa gerekir).
- **Zırh:** Elde sağ tık = giy, ya da envanterde zırh kutularına sürükle; kutuya tıklayınca çıkar. Her koruma puanı hasarı %4 azaltır (en çok %80). Kayda yazılır, karakterde görünür.
- **Yabani bitkiler:** Çimende 5 çiçek (Gelincik, Papatya, Lavanta, Karahindiba, Peygamber Çiçeği) ve uzun ot. Sol tıkla toplanır, **Yabani Tohum** düşürür (uzun otta %40 şans), bir süre sonra yeniden büyür.
- **Yabani Tohum:** Sürülmüş toprağa ekince bitki sayısı N olmak üzere her bitki eşit şansla (%100/N) çıkar. Yeni bitkiler: karpuz, kavun, patlıcan. Şans eşyanın üstüne gelince görünür.
- **Karakter:** Bakır golem tarzı sevimli yeni model, toplam boy 1,75 blok (2 blokluk geçitten geçer). Hayvanlar da daha sevimli yeniden modellendi.

## Gece canavarları

- Gece olunca (hayatta kalma modunda, yaratıcı mod ve güvenli modda çıkmaz) oyuncunun 16-30 blok çevresinde en fazla 7 canavar doğar: **Zombi**, **İskelet**, **Gece Örümceği**. Sadece yakındaki oyuncuyu kovalarlar.
- Zombi ve iskelet gündüz açıkta yanar; örümcekler sabah kaybolur. Canavarlar et, çubuk, yün ve kömür düşürür. Zırh canavar hasarını da azaltır.
- Sohbet komutları: `/canavar zombi|iskelet|orumcek` (çağır), `/gececanavari ac|kapat`, `/zaman gece` ile hemen gece yap.
- Çok oyunculuda canavarlar şimdilik sadece host tarafında oynanır.

## Sandık ve Fırın
- **Sandık** (8 tahta, masada): sağ tıkla aç, 27 kutu. Kırınca içindekiler yere düşer. Sürükle-bırak veya Shift+tık ile aktarım.
- **Fırın** (8 kırıktaş): sağ tıkla aç. Üst kutu = eritilecek, alt kutu = yakıt, sağ kutu = sonuç (sadece alınır).
  - Eritme: ham bakır/demir/altın → külçe, çiğ et → pişmiş et, odun → kömür, kil → tuğla, kırıktaş → taş (8 sn).
  - Yakıt: kömür (80 sn), odun (15), tahta (12), sopa (5).
  - Fırın sen yakınken (48 blok) çalışmaya devam eder; yakınındayken pişirme/ocak ısısı da sayılır.
- Sandık/fırın içerikleri kayıt dosyasına yazılır. Çok oyunculuda yalnızca ana bilgisayarda çalışır.
- Çömelip elinde blok varken sağ tık: sandığın yanına blok koyar.
